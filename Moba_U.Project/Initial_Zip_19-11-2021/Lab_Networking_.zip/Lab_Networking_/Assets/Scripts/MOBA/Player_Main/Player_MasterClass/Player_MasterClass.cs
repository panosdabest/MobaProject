using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Player_MasterClass : MonoBehaviour, IAttacker {
    //If someone prefers the struct approach is more than welcome to use it/recommend exclusive use...
    public struct PlayerData {
        float health;
        float mana;
        float attackPoints;
        float armor;
    }
    public enum PlayerState {
        Idle,
        Walking,
        Running,
        Healthy,
        Damaged,
        Attacking,
        Healing
    }
    [Tooltip("Assign the number of abilities & their properties")]
    [Header("Player Ability/ies")]
    [SerializeField] public Ability[] abillities;
    [Header("Player Statistics")]
    [SerializeField] public  float health;
    [SerializeField] public float mana;
    [SerializeField] public float attackPoints;
    [SerializeField] public float armor;
    [Header("Camera Movement")]
    [SerializeField] private Camera playerCamera;
    [Header("Player State")]
    public PlayerState playerState = PlayerState.Idle;
    public Player_MasterClass() { }
    public Player_MasterClass(PlayerData playerData) { }
    public Player_MasterClass(float health, float mana, float attackPoints, float armor) {
        this.health = health;
        this.mana = mana;
        this.attackPoints = attackPoints;
        this.armor = armor;
    }
    public virtual void InvokeAbility(string Name) {
        for (int i = 0; i < abillities.Length; i++) {
            if(abillities[i].abilityName.Equals(Name)) {
                abillities[i].InvokeAbility();
            }
        }
    }
    public virtual void InflictPhysicalDamage(float originalInflictedValue, float damage) { }

    public virtual void InflictStatisticalDamage(float originalValue, float debuff) { }
}